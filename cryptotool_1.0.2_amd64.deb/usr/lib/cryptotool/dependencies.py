import os
import sys
import platform
import subprocess
from pathlib import Path
from rich.console import Console

console = Console()

class DependencyManager:
    def __init__(self):
        self.base_path = Path(getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
        self.openssl_path = self._prepare_openssl()
        
    def _prepare_openssl(self):
        """Gère les binaires OpenSSL embarqués"""
        openssl_dir = self.base_path / "openssl"
        openssl_bin = openssl_dir / ("openssl.exe" if platform.system() == "Windows" else "openssl")
        
        if not openssl_bin.exists():
            # Mode développement - utilise le système
            return "openssl"
            
        # Mode packagé - utilise notre binaire
        os.environ['PATH'] = f"{openssl_dir}{os.pathsep}{os.environ['PATH']}"
        return str(openssl_bin)

    def check_all(self):
        """Vérifie toutes les dépendances"""
        checks = [
            ("OpenSSL", self._check_openssl()),
            ("Python Rich", self._check_python_import("rich")),
            ("Python PyFiglet", self._check_python_import("pyfiglet"))
        ]
        
        return all(status for _, status in checks)

    def _check_openssl(self):
        try:
            result = subprocess.run(
                [self.openssl_path, "version"],
                capture_output=True,
                text=True,
                check=True
            )
            return "OpenSSL" in result.stdout
        except:
            return False

    def _check_python_import(self, package):
        try:
            __import__(package)
            return True
        except ImportError:
            return False

    def install_missing(self):
        """Tente d'installer les dépendances manquantes"""
        # Implémentation simplifiée
        if not self._check_openssl():
            console.print("[red]OpenSSL doit être installé manuellement[/red]")
            return False
            
        missing_python = []
        for pkg in ["rich", "pyfiglet"]:
            if not self._check_python_import(pkg):
                missing_python.append(pkg)
        
        if missing_python:
            try:
                subprocess.run([sys.executable, "-m", "pip", "install", *missing_python], check=True)
                return True
            except:
                return False
        return True